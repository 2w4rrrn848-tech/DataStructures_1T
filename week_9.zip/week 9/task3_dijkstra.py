student_name = ""
student_id = ""

INF = 10 ** 9
NONE = -1
NAMES = ["A", "B", "C", "D", "E", "F"]

G2_EDGES = [("A", "B", 4), ("A", "C", 2), ("B", "C", 1), ("B", "D", 5), ("C", "D", 8),
            ("C", "E", 10), ("D", "E", 2), ("D", "F", 6), ("E", "F", 3)]


def idx(name):
    return NAMES.index(name)


G2 = [[] for _ in NAMES]
for a, b, w in G2_EDGES:
    G2[idx(a)].append((idx(b), w))
    G2[idx(b)].append((idx(a), w))
for lst in G2:
    lst.sort()


def dist_text(dist):
    return " ".join(f"{NAMES[i]}={'INF' if d == INF else d}" for i, d in enumerate(dist))


def dijkstra(graph, source):
    n = len(graph)
    dist = [INF] * n
    prev = [NONE] * n
    settled = [False] * n
    dist[source] = 0
    print("init | " + dist_text(dist))
    while True:
        u = NONE
        for i in range(n):
            if not settled[i] and dist[i] < INF and (u == NONE or dist[i] < dist[u]):
                u = i
        if u == NONE:
            break
        settled[u] = True
        for v, w in graph[u]:
            if not settled[v] and dist[u] + w < dist[v]:
                dist[v] = dist[u] + w
                prev[v] = u
        print(f"settle {NAMES[u]} ({dist[u]}) | " + dist_text(dist))
    return dist, prev


def path_from(prev, target):
    path = []
    v = target
    while v != NONE:
        path.append(v)
        v = prev[v]
    path.reverse()
    return path


def main():
    dist, prev = dijkstra(G2, idx("A"))
    for t in range(1, len(G2)):
        p = " -> ".join(NAMES[i] for i in path_from(prev, t))
        print(f"A to {NAMES[t]}: cost {dist[t]}: {p}")


if __name__ == "__main__":
    main()
