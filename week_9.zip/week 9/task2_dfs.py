student_name = ""
student_id = ""

NAMES = ["A", "B", "C", "D", "E", "F", "G"]

G1_EDGES = [("A", "B"), ("A", "C"), ("B", "D"), ("B", "E"), ("C", "F"), ("E", "F"), ("F", "G")]


def idx(name):
    return NAMES.index(name)


G1 = [[] for _ in NAMES]
for a, b in G1_EDGES:
    G1[idx(a)].append(idx(b))
    G1[idx(b)].append(idx(a))
for lst in G1:
    lst.sort()


class Stack:
    def __init__(self, capacity):
        self.data = [0] * capacity
        self.top = 0

    def push(self, x):
        self.data[self.top] = x
        self.top += 1

    def pop(self):
        self.top -= 1
        return self.data[self.top]

    def is_empty(self):
        return self.top == 0


def dfs(graph, start):
    n = len(graph)
    visited = [False] * n
    s = Stack(n * n)
    s.push(start)
    order = []
    while not s.is_empty():
        u = s.pop()
        if visited[u]:
            continue
        visited[u] = True
        order.append(u)
        for v in reversed(graph[u]):
            if not visited[v]:
                s.push(v)
    return order


def main():
    for start in ("A", "G"):
        order = dfs(G1, idx(start))
        print(f"DFS order from {start}: " + " ".join(NAMES[i] for i in order))


if __name__ == "__main__":
    main()
