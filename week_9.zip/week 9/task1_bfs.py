student_name = ""
student_id = ""

NONE = -1
NAMES = ["A", "B", "C", "D", "E", "F", "G"]

G1_EDGES = [("A", "B"), ("A", "C"), ("B", "D"), ("B", "E"), ("C", "F"), ("E", "F"), ("F", "G")]


def idx(name):
    return NAMES.index(name)


G1 = [[] for _ in NAMES]
for a, b in G1_EDGES:
    G1[idx(a)].append(idx(b))
    G1[idx(b)].append(idx(a))
for lst in G1:
    lst.sort()


class Queue:
    def __init__(self, capacity):
        self.data = [0] * capacity
        self.front = 0
        self.back = 0

    def enqueue(self, x):
        self.data[self.back] = x
        self.back += 1

    def dequeue(self):
        x = self.data[self.front]
        self.front += 1
        return x

    def is_empty(self):
        return self.front == self.back


def bfs(graph, start):
    n = len(graph)
    discovered = [False] * n
    dist = [NONE] * n
    parent = [NONE] * n
    q = Queue(n)
    discovered[start] = True
    dist[start] = 0
    q.enqueue(start)
    order = []
    while not q.is_empty():
        u = q.dequeue()
        order.append(u)
        for v in graph[u]:
            if not discovered[v]:
                discovered[v] = True
                dist[v] = dist[u] + 1
                parent[v] = u
                q.enqueue(v)
    return order, dist, parent


def path_from(parent, target):
    path = []
    v = target
    while v != NONE:
        path.append(v)
        v = parent[v]
    path.reverse()
    return path


def shortest(graph, s, t):
    order, dist, parent = bfs(graph, s)
    if dist[t] == NONE:
        return f"Shortest {NAMES[s]} -> {NAMES[t]}: no path"
    p = " -> ".join(NAMES[i] for i in path_from(parent, t))
    return f"Shortest {NAMES[s]} -> {NAMES[t]}: distance {dist[t]}, path {p}"


def main():
    order = bfs(G1, idx("A"))[0]
    print("BFS order from A: " + " ".join(NAMES[i] for i in order))
    print(shortest(G1, idx("A"), idx("G")))
    print(shortest(G1, idx("D"), idx("G")))


if __name__ == "__main__":
    main()
